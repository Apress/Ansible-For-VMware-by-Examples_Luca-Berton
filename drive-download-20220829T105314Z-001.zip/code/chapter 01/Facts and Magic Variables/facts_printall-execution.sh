#!/bin/bash
ansible-playbook -i inventory facts_printall.yml
