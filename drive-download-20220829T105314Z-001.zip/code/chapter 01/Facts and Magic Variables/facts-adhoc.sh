#!/bin/bah
ansible -m setup one.example.com
