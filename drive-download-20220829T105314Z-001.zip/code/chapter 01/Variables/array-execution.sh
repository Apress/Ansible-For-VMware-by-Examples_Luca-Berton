#!/bin/bash
ansible-playbook -i inventory array.yml
