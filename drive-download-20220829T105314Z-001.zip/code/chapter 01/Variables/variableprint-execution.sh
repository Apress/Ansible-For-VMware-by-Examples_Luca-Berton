#!/bin/bash
ansible-playbook -i inventory variableprint.yml