#!/bin/bash
ansible-playbook -i inventory registeredvariables.yml