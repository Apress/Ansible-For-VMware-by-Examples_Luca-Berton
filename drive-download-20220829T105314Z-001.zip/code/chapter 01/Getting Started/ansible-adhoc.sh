#!/bin/bash
ansible all -a '/bin/echo example'
