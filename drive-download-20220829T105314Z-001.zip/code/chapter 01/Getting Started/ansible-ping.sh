#!/bin/bash
ansible all -m ping
