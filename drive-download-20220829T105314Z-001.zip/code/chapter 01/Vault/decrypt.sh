#!/bin/bash
ansible-vault decrypt secret.yml --output=cleartext.yml
