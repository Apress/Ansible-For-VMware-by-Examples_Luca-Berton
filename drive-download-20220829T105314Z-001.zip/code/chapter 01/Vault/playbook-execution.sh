#!/bin/bash
ansible-playbook --vault-id @prompt playbook.yml
