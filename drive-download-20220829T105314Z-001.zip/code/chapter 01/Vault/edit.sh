#!/bin/bash
ansible-vault edit secret.yml
