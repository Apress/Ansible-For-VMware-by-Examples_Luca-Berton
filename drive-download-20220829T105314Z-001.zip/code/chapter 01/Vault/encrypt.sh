#!/bin/bash
ansible-vault encrypt cleartext.yml --output=secret.yml
