#!/bin/bash
ansible-vault create --vault-password-file=password.txt secret.yml
