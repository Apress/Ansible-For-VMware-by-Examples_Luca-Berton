#!/bin/bash
ansible-vault rekey secret.yml
