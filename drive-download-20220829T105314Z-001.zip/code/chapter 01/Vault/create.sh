#!/bin/bash
ansible-vault create secret.yml
