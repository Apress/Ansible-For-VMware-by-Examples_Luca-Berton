#!/bin/bash
ansible-playbook --vault-password-file=vault-password.txt playbook.yml
