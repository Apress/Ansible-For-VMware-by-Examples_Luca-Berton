#!/bin/bash
ansible-vault view secret.yml
