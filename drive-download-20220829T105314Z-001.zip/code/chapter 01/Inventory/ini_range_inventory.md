[frontends]
www[01:99].example.com

[backends]
back-[a-f].example.com
