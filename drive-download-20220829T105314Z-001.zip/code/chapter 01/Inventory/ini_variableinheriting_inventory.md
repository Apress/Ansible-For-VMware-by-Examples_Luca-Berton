[asia]
host1.example.com

[europe]
host2.example.com

[webserver:children]
asia
europe

[frontends:vars]
ntp_server=europe.pool.ntp.org
