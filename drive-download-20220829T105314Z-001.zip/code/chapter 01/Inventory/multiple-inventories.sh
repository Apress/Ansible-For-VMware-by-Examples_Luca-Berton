#!/bin/bash
ansible-playbook -i production -i development playbook.yml
