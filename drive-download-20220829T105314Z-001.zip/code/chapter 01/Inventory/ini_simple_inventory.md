host1.example.com

[frontends]
host2.example.com
host3.example.com
