#!/bin/bash
ansible-playbook -i inventory --check helloworld.yml
