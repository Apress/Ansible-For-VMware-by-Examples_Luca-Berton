#!/bin/bash
ansible-playbook -i inventory helloworld_debug.yml
