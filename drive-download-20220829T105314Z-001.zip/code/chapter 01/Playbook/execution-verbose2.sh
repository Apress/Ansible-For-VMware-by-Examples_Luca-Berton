#!/bin/bash
ansible-playbook -i inventory -vv helloworld_debug.yml
