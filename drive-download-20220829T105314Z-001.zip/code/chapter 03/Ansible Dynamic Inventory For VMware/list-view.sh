#!/bin/bash
ansible-inventory -i inventory.vmware.yml --list
