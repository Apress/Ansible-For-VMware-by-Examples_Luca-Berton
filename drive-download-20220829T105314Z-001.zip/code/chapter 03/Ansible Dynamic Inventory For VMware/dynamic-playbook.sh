#!/bin/bash
ansible-playbook -i inventory.vmware.yml playbook.yml
