#!/bin/bash
sudo pip install PyVmomi
