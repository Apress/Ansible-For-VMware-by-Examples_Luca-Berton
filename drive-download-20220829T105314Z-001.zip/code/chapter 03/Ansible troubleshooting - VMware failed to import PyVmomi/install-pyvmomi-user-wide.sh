#!/bin/bash
pip install --user PyVmomi
