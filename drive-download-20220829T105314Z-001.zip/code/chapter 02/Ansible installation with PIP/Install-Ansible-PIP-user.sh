#!/bin/bash
python -m pip install --upgrade -user pip
python -m pip install --user ansible
