#!/bin/bash
dnf install ansible
