#!/bin/bash
sudo amazon-linux-extras install ansible2 -y
