#!/bin/sh
brew install ansible
