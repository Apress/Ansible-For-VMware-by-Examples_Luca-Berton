#!/bin/bash
dnf install ansible-core