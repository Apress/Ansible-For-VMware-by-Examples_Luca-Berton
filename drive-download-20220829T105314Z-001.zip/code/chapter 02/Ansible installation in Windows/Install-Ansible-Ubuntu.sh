#!/bin/bash
sudo apt-get install ansible
