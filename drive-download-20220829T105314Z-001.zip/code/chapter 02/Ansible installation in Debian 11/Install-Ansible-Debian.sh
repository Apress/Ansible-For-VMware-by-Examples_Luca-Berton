#!/bin/bash
apt update
apt install ansible
