#!/bin/bash
SUSEConnect -p PackageHub/15.3/x86_64
zypper install ansible
